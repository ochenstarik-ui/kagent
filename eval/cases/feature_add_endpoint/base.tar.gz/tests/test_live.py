import unittest

from app import dispatch


class ExistingEndpointTests(unittest.TestCase):
    def test_live_endpoint(self) -> None:
        self.assertEqual(dispatch("GET", "/health/live"), (200, {"status": "live"}))

    def test_unknown_endpoint(self) -> None:
        self.assertEqual(dispatch("GET", "/missing")[0], 404)


if __name__ == "__main__":
    unittest.main()
