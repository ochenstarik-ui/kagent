A tiny stdlib HTTP-dispatch exercise; no server or network is needed.
