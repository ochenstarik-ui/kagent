from time import monotonic

_STARTED = monotonic()


def dispatch(method: str, path: str) -> tuple[int, dict[str, object]]:
    if method == "GET" and path == "/health/live":
        return 200, {"status": "live"}
    return 404, {"error": "not found"}
