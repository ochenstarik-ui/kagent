A standard-library response-building security exercise.
