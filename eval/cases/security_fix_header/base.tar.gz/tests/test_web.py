import unittest

from web import response


class ExistingResponseTests(unittest.TestCase):
    def test_custom_header_is_preserved(self) -> None:
        self.assertEqual(response("/", {"X-Request-ID": "abc"})[2]["X-Request-ID"], "abc")

    def test_missing_path_is_404(self) -> None:
        self.assertEqual(response("/missing")[0], 404)


if __name__ == "__main__":
    unittest.main()
