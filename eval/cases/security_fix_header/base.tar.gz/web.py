def response(path: str, headers: dict[str, str] | None = None) -> tuple[int, str, dict[str, str]]:
    response_headers = dict(headers or {})
    if path == "/":
        return 200, "home", response_headers
    return 404, "not found", response_headers
