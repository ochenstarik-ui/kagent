A small standard-library rate limiter exercise. Run `python -m unittest discover -s tests`.
