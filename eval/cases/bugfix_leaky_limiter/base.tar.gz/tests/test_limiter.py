import unittest

from limiter import RateLimiter


class RateLimiterTests(unittest.TestCase):
    def test_limit_counts_first_request(self) -> None:
        limiter = RateLimiter(limit=2)
        self.assertEqual([limiter.allow("a") for _ in range(3)], [True, True, False])

    def test_clients_have_independent_budgets(self) -> None:
        limiter = RateLimiter(limit=1)
        self.assertTrue(limiter.allow("a"))
        self.assertTrue(limiter.allow("b"))


if __name__ == "__main__":
    unittest.main()
