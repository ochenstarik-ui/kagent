class RateLimiter:
    def __init__(self, limit: int = 2) -> None:
        self.limit = limit
        self._counts: dict[str, int] = {}

    def allow(self, client: str) -> bool:
        count = self._counts.get(client, 0)
        if count >= self.limit:
            return False
        self._counts[client] = count if client not in self._counts else count + 1
        return True
